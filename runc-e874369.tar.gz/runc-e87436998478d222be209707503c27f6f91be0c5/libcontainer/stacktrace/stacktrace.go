package stacktrace

type Stacktrace struct {
	Frames []Frame
}
