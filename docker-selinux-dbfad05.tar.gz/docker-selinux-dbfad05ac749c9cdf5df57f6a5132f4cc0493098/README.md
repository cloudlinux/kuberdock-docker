SELinux policy for docker
