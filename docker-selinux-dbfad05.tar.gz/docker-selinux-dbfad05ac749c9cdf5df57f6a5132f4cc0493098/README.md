RHEL SELinux policy for docker 
