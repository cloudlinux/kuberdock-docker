package main

// TODO Windows: This will have a very different implementation
func createStdio() (s stdio, err error) {
	return stdio{}, nil
}
