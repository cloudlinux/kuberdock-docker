package supervisor

func CollectMachineInformation() (Machine, error) {
	return Machine{}, nil
}
