fsrv
====

Dumb simple static file server. 

Easy access for testing the static registry tree


Usage
=====

  $> fsrv ./registry
  2014/05/05 11:26:25 Serving /home/vbatts/sandbox/d2r/registry on 127.0.0.1:5000 ...


