package version

var VERSION = "1.0.1-dev"
