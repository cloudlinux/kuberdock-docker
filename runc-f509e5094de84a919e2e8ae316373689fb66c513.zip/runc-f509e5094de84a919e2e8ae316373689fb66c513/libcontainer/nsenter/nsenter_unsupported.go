// +build !linux !cgo

package nsenter

import "C"
