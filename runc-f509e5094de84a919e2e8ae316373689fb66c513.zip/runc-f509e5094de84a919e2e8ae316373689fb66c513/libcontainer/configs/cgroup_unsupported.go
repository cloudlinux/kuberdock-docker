// +build !windows,!linux,!freebsd

package configs

type Cgroup struct {
}
