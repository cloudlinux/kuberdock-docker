package libcontainer

type Stats struct {
	Interfaces []*NetworkInterface
}
