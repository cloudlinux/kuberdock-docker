# 0.7.3

formatter/\*: allow configuration of timestamp layout

# 0.7.2

formatter/text: Add configuration option for time format (#158)
