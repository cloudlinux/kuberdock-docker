// +build !gccgo

package ioutils

func callSchedulerIfNecessary() {
}
