// +build !linux

package gelf
