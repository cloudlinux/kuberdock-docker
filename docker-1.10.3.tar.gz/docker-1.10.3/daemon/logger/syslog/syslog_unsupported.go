// +build !linux

package syslog
