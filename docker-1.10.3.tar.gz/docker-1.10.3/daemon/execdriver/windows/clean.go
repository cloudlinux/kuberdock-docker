// +build windows

package windows

// Clean implements the exec driver Driver interface.
func (d *Driver) Clean(id string) error {
	return nil
}
