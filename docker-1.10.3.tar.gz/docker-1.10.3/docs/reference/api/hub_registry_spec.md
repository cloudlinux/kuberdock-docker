<!--[metadata]>
+++
draft = true
title = "The Docker Hub and the Registry v1"
description = "Documentation for docker Registry and Registry API"
keywords = ["docker, registry, api,  hub"]
[menu.main]
parent="smn_hub_ref"
+++
<![end-metadata]-->

# The Docker Hub and the Registry v1

This API is deprecated as of 1.7. To view the old version, see the [go
here](hub_registry_spec.md) in
the 1.7 documentation. If you want an overview of the current features in
Docker Hub or other image management features see the [image management
overview](../../userguide/eng-image/image_management.md) in the current documentation set.
